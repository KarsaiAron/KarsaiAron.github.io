t = list(map(lambda x: list(map(int, x.split("!"))),open("input.txt").read().split("\n")))
import math
def elso():
    i = []
    while len(i) != 10:
        i.append(max(t[0])**2)
        t[0].remove(max(t[0]))

    return sum(i)

def masodik():
    l = 1
    for i in t[1]:
        l *= i
    return math.log10(l)

def harmadik():
    o = []
    for i in t[2]:
        if i % 2 ==1:
            o.append(i)
    return max(o)

def negyedik():
    o = []
    for i in t[3]:
        if i % 3 ==0:
            o.append(i)
    return sum(o)

def otodik():
    o = []
    for i in t[4]:
        if i > 9:
            o.append(i)
    return min(o)

def hatodik():
    p = []
    for j in t:
        for n in j:
            if n % 2 ==0:
                p.append(n)
    return sum(p) / len(p)




print(f'Az 1. sorban szereplő 10 legnagyobb szám négyzeteinek összege: {elso()}')
print(f'A  2. sorban szereplő számok szorzatának nagyságrendje: 10^{masodik()}')    
print(f'A  3. sorban szereplő páratlan számok maximuma: {harmadik()}')
print(f'A  4. sorban szereplő hárommal osztható számok összege: {negyedik()}')     
print(f'Az 5. sorban szereplő 9-nél nagyobb számok minimuma: {otodik()}')
print(f'Az inputban szereplő összes szám közül a páros számok számtani közepe: {hatodik()}')